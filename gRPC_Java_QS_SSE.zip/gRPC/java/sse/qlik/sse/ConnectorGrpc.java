package qlik.sse;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 **
 * The communication service provided between the Qlik engine and the plugin.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.37.0)",
    comments = "Source: ServerSideExtension.proto")
public final class ConnectorGrpc {

  private ConnectorGrpc() {}

  public static final String SERVICE_NAME = "qlik.sse.Connector";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.Empty,
      qlik.sse.ServerSideExtension.Capabilities> getGetCapabilitiesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCapabilities",
      requestType = qlik.sse.ServerSideExtension.Empty.class,
      responseType = qlik.sse.ServerSideExtension.Capabilities.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.Empty,
      qlik.sse.ServerSideExtension.Capabilities> getGetCapabilitiesMethod() {
    io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.Empty, qlik.sse.ServerSideExtension.Capabilities> getGetCapabilitiesMethod;
    if ((getGetCapabilitiesMethod = ConnectorGrpc.getGetCapabilitiesMethod) == null) {
      synchronized (ConnectorGrpc.class) {
        if ((getGetCapabilitiesMethod = ConnectorGrpc.getGetCapabilitiesMethod) == null) {
          ConnectorGrpc.getGetCapabilitiesMethod = getGetCapabilitiesMethod =
              io.grpc.MethodDescriptor.<qlik.sse.ServerSideExtension.Empty, qlik.sse.ServerSideExtension.Capabilities>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCapabilities"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.Capabilities.getDefaultInstance()))
              .setSchemaDescriptor(new ConnectorMethodDescriptorSupplier("GetCapabilities"))
              .build();
        }
      }
    }
    return getGetCapabilitiesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows,
      qlik.sse.ServerSideExtension.BundledRows> getExecuteFunctionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExecuteFunction",
      requestType = qlik.sse.ServerSideExtension.BundledRows.class,
      responseType = qlik.sse.ServerSideExtension.BundledRows.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows,
      qlik.sse.ServerSideExtension.BundledRows> getExecuteFunctionMethod() {
    io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows, qlik.sse.ServerSideExtension.BundledRows> getExecuteFunctionMethod;
    if ((getExecuteFunctionMethod = ConnectorGrpc.getExecuteFunctionMethod) == null) {
      synchronized (ConnectorGrpc.class) {
        if ((getExecuteFunctionMethod = ConnectorGrpc.getExecuteFunctionMethod) == null) {
          ConnectorGrpc.getExecuteFunctionMethod = getExecuteFunctionMethod =
              io.grpc.MethodDescriptor.<qlik.sse.ServerSideExtension.BundledRows, qlik.sse.ServerSideExtension.BundledRows>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExecuteFunction"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.BundledRows.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.BundledRows.getDefaultInstance()))
              .setSchemaDescriptor(new ConnectorMethodDescriptorSupplier("ExecuteFunction"))
              .build();
        }
      }
    }
    return getExecuteFunctionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows,
      qlik.sse.ServerSideExtension.BundledRows> getEvaluateScriptMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "EvaluateScript",
      requestType = qlik.sse.ServerSideExtension.BundledRows.class,
      responseType = qlik.sse.ServerSideExtension.BundledRows.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows,
      qlik.sse.ServerSideExtension.BundledRows> getEvaluateScriptMethod() {
    io.grpc.MethodDescriptor<qlik.sse.ServerSideExtension.BundledRows, qlik.sse.ServerSideExtension.BundledRows> getEvaluateScriptMethod;
    if ((getEvaluateScriptMethod = ConnectorGrpc.getEvaluateScriptMethod) == null) {
      synchronized (ConnectorGrpc.class) {
        if ((getEvaluateScriptMethod = ConnectorGrpc.getEvaluateScriptMethod) == null) {
          ConnectorGrpc.getEvaluateScriptMethod = getEvaluateScriptMethod =
              io.grpc.MethodDescriptor.<qlik.sse.ServerSideExtension.BundledRows, qlik.sse.ServerSideExtension.BundledRows>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "EvaluateScript"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.BundledRows.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  qlik.sse.ServerSideExtension.BundledRows.getDefaultInstance()))
              .setSchemaDescriptor(new ConnectorMethodDescriptorSupplier("EvaluateScript"))
              .build();
        }
      }
    }
    return getEvaluateScriptMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ConnectorStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConnectorStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConnectorStub>() {
        @java.lang.Override
        public ConnectorStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConnectorStub(channel, callOptions);
        }
      };
    return ConnectorStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ConnectorBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConnectorBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConnectorBlockingStub>() {
        @java.lang.Override
        public ConnectorBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConnectorBlockingStub(channel, callOptions);
        }
      };
    return ConnectorBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ConnectorFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConnectorFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConnectorFutureStub>() {
        @java.lang.Override
        public ConnectorFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConnectorFutureStub(channel, callOptions);
        }
      };
    return ConnectorFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   **
   * The communication service provided between the Qlik engine and the plugin.
   * </pre>
   */
  public static abstract class ConnectorImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     *&#47; A handshake call for the Qlik engine to retrieve the capability of the plugin.
     * </pre>
     */
    public void getCapabilities(qlik.sse.ServerSideExtension.Empty request,
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.Capabilities> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCapabilitiesMethod(), responseObserver);
    }

    /**
     * <pre>
     *&#47; Requests a function to be executed as specified in the header.
     * </pre>
     */
    public io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> executeFunction(
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getExecuteFunctionMethod(), responseObserver);
    }

    /**
     * <pre>
     *&#47; Requests a script to be evaluated as specified in the header.
     * </pre>
     */
    public io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> evaluateScript(
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getEvaluateScriptMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetCapabilitiesMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                qlik.sse.ServerSideExtension.Empty,
                qlik.sse.ServerSideExtension.Capabilities>(
                  this, METHODID_GET_CAPABILITIES)))
          .addMethod(
            getExecuteFunctionMethod(),
            io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
              new MethodHandlers<
                qlik.sse.ServerSideExtension.BundledRows,
                qlik.sse.ServerSideExtension.BundledRows>(
                  this, METHODID_EXECUTE_FUNCTION)))
          .addMethod(
            getEvaluateScriptMethod(),
            io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
              new MethodHandlers<
                qlik.sse.ServerSideExtension.BundledRows,
                qlik.sse.ServerSideExtension.BundledRows>(
                  this, METHODID_EVALUATE_SCRIPT)))
          .build();
    }
  }

  /**
   * <pre>
   **
   * The communication service provided between the Qlik engine and the plugin.
   * </pre>
   */
  public static final class ConnectorStub extends io.grpc.stub.AbstractAsyncStub<ConnectorStub> {
    private ConnectorStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConnectorStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConnectorStub(channel, callOptions);
    }

    /**
     * <pre>
     *&#47; A handshake call for the Qlik engine to retrieve the capability of the plugin.
     * </pre>
     */
    public void getCapabilities(qlik.sse.ServerSideExtension.Empty request,
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.Capabilities> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCapabilitiesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     *&#47; Requests a function to be executed as specified in the header.
     * </pre>
     */
    public io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> executeFunction(
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getExecuteFunctionMethod(), getCallOptions()), responseObserver);
    }

    /**
     * <pre>
     *&#47; Requests a script to be evaluated as specified in the header.
     * </pre>
     */
    public io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> evaluateScript(
        io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getEvaluateScriptMethod(), getCallOptions()), responseObserver);
    }
  }

  /**
   * <pre>
   **
   * The communication service provided between the Qlik engine and the plugin.
   * </pre>
   */
  public static final class ConnectorBlockingStub extends io.grpc.stub.AbstractBlockingStub<ConnectorBlockingStub> {
    private ConnectorBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConnectorBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConnectorBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     *&#47; A handshake call for the Qlik engine to retrieve the capability of the plugin.
     * </pre>
     */
    public qlik.sse.ServerSideExtension.Capabilities getCapabilities(qlik.sse.ServerSideExtension.Empty request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCapabilitiesMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   **
   * The communication service provided between the Qlik engine and the plugin.
   * </pre>
   */
  public static final class ConnectorFutureStub extends io.grpc.stub.AbstractFutureStub<ConnectorFutureStub> {
    private ConnectorFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConnectorFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConnectorFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     *&#47; A handshake call for the Qlik engine to retrieve the capability of the plugin.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<qlik.sse.ServerSideExtension.Capabilities> getCapabilities(
        qlik.sse.ServerSideExtension.Empty request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCapabilitiesMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_CAPABILITIES = 0;
  private static final int METHODID_EXECUTE_FUNCTION = 1;
  private static final int METHODID_EVALUATE_SCRIPT = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ConnectorImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ConnectorImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_CAPABILITIES:
          serviceImpl.getCapabilities((qlik.sse.ServerSideExtension.Empty) request,
              (io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.Capabilities>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_EXECUTE_FUNCTION:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.executeFunction(
              (io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows>) responseObserver);
        case METHODID_EVALUATE_SCRIPT:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.evaluateScript(
              (io.grpc.stub.StreamObserver<qlik.sse.ServerSideExtension.BundledRows>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ConnectorBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ConnectorBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return qlik.sse.ServerSideExtension.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Connector");
    }
  }

  private static final class ConnectorFileDescriptorSupplier
      extends ConnectorBaseDescriptorSupplier {
    ConnectorFileDescriptorSupplier() {}
  }

  private static final class ConnectorMethodDescriptorSupplier
      extends ConnectorBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ConnectorMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ConnectorGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ConnectorFileDescriptorSupplier())
              .addMethod(getGetCapabilitiesMethod())
              .addMethod(getExecuteFunctionMethod())
              .addMethod(getEvaluateScriptMethod())
              .build();
        }
      }
    }
    return result;
  }
}
