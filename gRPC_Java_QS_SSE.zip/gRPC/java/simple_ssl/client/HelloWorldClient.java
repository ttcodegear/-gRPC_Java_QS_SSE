package client;

import java.util.concurrent.TimeUnit;

import io.grpc.Channel;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509ExtendedKeyManager;
import io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.NettyChannelBuilder;
import io.netty.handler.ssl.SslContext;
import nl.altindag.ssl.util.PemUtils;
import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.NettySslUtils;

import io.grpc.examples.helloworld.*;

public class HelloWorldClient {
  private GreeterGrpc.GreeterBlockingStub blockingStub;

  public HelloWorldClient(Channel channel) {
    blockingStub = GreeterGrpc.newBlockingStub(channel);
  }

  private void greet(String name) {
    try {
      HelloRequest request = HelloRequest.newBuilder().setName(name).build();
      HelloReply response = blockingStub.sayHello(request);
      System.out.println("Greeter client received: " + response.getMessage());
    }
    catch (StatusRuntimeException ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) throws Exception {
    X509ExtendedKeyManager keyManager = PemUtils.loadIdentityMaterial("server.crt", "server.key");
    X509ExtendedTrustManager trustManager = PemUtils.loadTrustMaterial("server.crt");
    // Trusting all certificates without validation, not recommended to use at production!
    SSLFactory sslFactory = SSLFactory.builder().withIdentityMaterial(keyManager).withTrustMaterial(trustManager).withTrustingAllCertificatesWithoutValidation().build();
    SslContext sslContext = GrpcSslContexts.configure(NettySslUtils.forClient(sslFactory)).build();

    // Channels are thread-safe and reusable.
    ManagedChannel channel = null;
    try {
      channel = NettyChannelBuilder.forAddress("jatok-tts1", 50051).sslContext(sslContext).build();
      HelloWorldClient client = new HelloWorldClient(channel);
      client.greet("山田太郎");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    finally {
      if(channel != null)
        channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
    }
  }
}
