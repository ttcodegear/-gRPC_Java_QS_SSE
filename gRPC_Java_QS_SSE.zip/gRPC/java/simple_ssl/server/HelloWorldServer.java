package server;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509ExtendedKeyManager;
import io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.NettyServerBuilder;
import io.netty.handler.ssl.SslContext;
import nl.altindag.ssl.util.PemUtils;
import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.NettySslUtils;

import io.grpc.examples.helloworld.*;

class GreeterImpl extends GreeterGrpc.GreeterImplBase {
  @Override
  public void sayHello(HelloRequest request, StreamObserver<HelloReply> responseObserver) {
    System.out.println("Received request:" + request);
    HelloReply reply = HelloReply.newBuilder().setMessage("こんにちは " + request.getName()).build();
    responseObserver.onNext(reply);
    responseObserver.onCompleted();
  }
}

public class HelloWorldServer {
  private Server server;

  private void start() throws IOException {
    X509ExtendedKeyManager keyManager = PemUtils.loadIdentityMaterial("server.crt", "server.key");
    X509ExtendedTrustManager trustManager = PemUtils.loadTrustMaterial("server.crt");
    SSLFactory sslFactory = SSLFactory.builder().withIdentityMaterial(keyManager).withTrustMaterial(trustManager).build();
    SslContext sslContext = GrpcSslContexts.configure(NettySslUtils.forServer(sslFactory)).build();

    server = NettyServerBuilder.forPort(50051).addService(new GreeterImpl()).sslContext(sslContext).build().start();
    Runtime.getRuntime().addShutdownHook(new Thread() {
      @Override
      public void run() {
        try {
          HelloWorldServer.this.server.shutdown().awaitTermination(10, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
          ex.printStackTrace();
        }
      }
    });
  }

  public static void main(String[] args) throws Exception {
    HelloWorldServer helloserver = new HelloWorldServer();
    helloserver.start();
    // Await termination on the main thread since the grpc library uses daemon threads.
    helloserver.server.awaitTermination();
  }
}
