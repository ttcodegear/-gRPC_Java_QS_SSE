package client;

import java.util.concurrent.TimeUnit;

import io.grpc.Channel;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

import io.grpc.examples.helloworld.*;

public class HelloWorldClient {
  private GreeterGrpc.GreeterBlockingStub blockingStub;

  public HelloWorldClient(Channel channel) {
    blockingStub = GreeterGrpc.newBlockingStub(channel);
  }

  private void greet(String name) {
    try {
      HelloRequest request = HelloRequest.newBuilder().setName(name).build();
      HelloReply response = blockingStub.sayHello(request);
      System.out.println("Greeter client received: " + response.getMessage());
    }
    catch (StatusRuntimeException ex) {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) throws Exception {
    // Channels are thread-safe and reusable.
    ManagedChannel channel = null;
    try {
      channel = ManagedChannelBuilder.forTarget("localhost:50051").usePlaintext().build();
      HelloWorldClient client = new HelloWorldClient(channel);
      client.greet("山田太郎");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    finally {
      if(channel != null)
        channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
    }
  }
}
