package server;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import io.grpc.examples.helloworld.*;

class GreeterImpl extends GreeterGrpc.GreeterImplBase {
  @Override
  public void sayHello(HelloRequest request, StreamObserver<HelloReply> responseObserver) {
    System.out.println("Received request:" + request);
    HelloReply reply = HelloReply.newBuilder().setMessage("こんにちは " + request.getName()).build();
    responseObserver.onNext(reply);
    responseObserver.onCompleted();
  }
}

public class HelloWorldServer {
  private Server server;

  private void start() throws IOException {
    server = ServerBuilder.forPort(50051).addService(new GreeterImpl()).build().start();
    Runtime.getRuntime().addShutdownHook(new Thread() {
      @Override
      public void run() {
        try {
          HelloWorldServer.this.server.shutdown().awaitTermination(10, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
          ex.printStackTrace();
        }
      }
    });
  }

  public static void main(String[] args) throws Exception {
    HelloWorldServer helloserver = new HelloWorldServer();
    helloserver.start();
    // Await termination on the main thread since the grpc library uses daemon threads.
    helloserver.server.awaitTermination();
  }
}
