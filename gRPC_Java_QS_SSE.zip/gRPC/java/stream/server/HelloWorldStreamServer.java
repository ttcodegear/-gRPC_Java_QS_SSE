package server;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import io.grpc.examples.helloworldstream.*;

class MultiGreeterImpl extends MultiGreeterGrpc.MultiGreeterImplBase {
  @Override
  public StreamObserver<HelloRequest> sayHello(StreamObserver<HelloReply> responseObserver) {
    return new StreamObserver<HelloRequest>() {
      @Override
      public void onNext(HelloRequest request) {
        System.out.println("Received request:" + request);
        int num = Integer.parseInt(request.getNumGreetings());
        for(int i = 0; i < num; i++) {
          String message = "こんにちは " + request.getName() + "! " + i;
          HelloReply reply = HelloReply.newBuilder().setMessage(message).build();
          responseObserver.onNext(reply);
        }
      }

      @Override
      public void onError(Throwable t) {
        t.printStackTrace();
      }

      @Override
      public void onCompleted() {
        responseObserver.onCompleted();
      }
    };
  }
}

public class HelloWorldStreamServer {
  private Server server;

  private void start() throws IOException {
    server = ServerBuilder.forPort(50052).addService(new MultiGreeterImpl()).build().start();
    Runtime.getRuntime().addShutdownHook(new Thread() {
      @Override
      public void run() {
        try {
          HelloWorldStreamServer.this.server.shutdown().awaitTermination(10, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
          ex.printStackTrace();
        }
      }
    });
  }

  public static void main(String[] args) throws Exception {
    HelloWorldStreamServer helloserver = new HelloWorldStreamServer();
    helloserver.start();
    // Await termination on the main thread since the grpc library uses daemon threads.
    helloserver.server.awaitTermination();
  }
}
