package client;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;

import io.grpc.Channel;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
//import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

import io.grpc.examples.helloworldstream.*;

public class HelloWorldStreamClient {
  private MultiGreeterGrpc.MultiGreeterStub asyncStub;

  public HelloWorldStreamClient(Channel channel) {
    asyncStub = MultiGreeterGrpc.newStub(channel);
  }

  private void greet() throws InterruptedException {
    final CountDownLatch finishLatch = new CountDownLatch(1);

    StreamObserver<HelloReply> responseObserver = new StreamObserver<HelloReply>() {
      @Override
      public void onNext(HelloReply response) {
        System.out.println("Greeter client received: " + response.getMessage());
      }

      @Override
      public void onError(Throwable t) {
        t.printStackTrace();
        finishLatch.countDown();
      }

      @Override
      public void onCompleted() {
        //System.out.println("Receive end");
        finishLatch.countDown();
      }
    };

    StreamObserver<HelloRequest> requestObserver = asyncStub.sayHello(responseObserver);
    try {
      HelloRequest request1 = HelloRequest.newBuilder().setName("山田太郎").setNumGreetings("5").build();
      requestObserver.onNext(request1);
      // RPC completed or errored before we finished sending. Sending further requests won't error, but they will just be thrown away.
      if(finishLatch.getCount() == 0)
        return;
      HelloRequest request2 = HelloRequest.newBuilder().setName("FooBar").setNumGreetings("5").build();
      requestObserver.onNext(request2);
    }
    catch (Exception ex) {
      requestObserver.onError(ex);
      throw ex;
    }
    requestObserver.onCompleted();

    if(!finishLatch.await(10, TimeUnit.SECONDS)) {
      ; // Client can not finish within 10 seconds
    }
  }

  public static void main(String[] args) throws Exception {
    // Channels are thread-safe and reusable.
    ManagedChannel channel = null;
    try {
      channel = ManagedChannelBuilder.forTarget("localhost:50052").usePlaintext().build();
      HelloWorldStreamClient client = new HelloWorldStreamClient(channel);
      client.greet();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    finally {
      if(channel != null)
        channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
    }
  }
}
